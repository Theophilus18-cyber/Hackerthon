import Login from './pages/Login';
import Registration from './pages/Register';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Community from './pages/Community';
import Courses from './pages/Courses';

import Resourses from './pages/Resourses';
import Home from './pages/Home';
import Navigation from './components/Navigation'
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/login" element={<Login />} />
        <Route path="/registration" element={<Registration />} />
        <Route
        path="/home" 
            element={
              <>
                < Navigation  />
                <Home />
              </>
            } 
         />
        <Route path="/community" element={<Community />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/resources" element={<Resourses />} />

      </Routes>
    </Router>
  );
}

export default App;

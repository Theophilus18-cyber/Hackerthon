import React, { useState } from 'react';
import { AppBar, Toolbar, Typography, Button, Dialog, DialogTitle, DialogContent, DialogContentText, Container } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const Navigation = () => {
  const [openAbout, setOpenAbout] = useState(false);
  const [openContact, setOpenContact] = useState(false);
  const navigate = useNavigate();

  const handleAboutOpen = () => {
    setOpenAbout(true);
  };

  const handleAboutClose = () => {
    setOpenAbout(false);
  };

  const handleContactOpen = () => {
    setOpenContact(true);
  };

  const handleContactClose = () => {
    setOpenContact(false);
  };

  function handleCartClick() {
    // Navigate to cart page
    navigate('/cart');
  };

  return (
    <>
      <AppBar position="static" style={{ backgroundColor: '#1976d2', width: '100vw' }}>
        <Toolbar style={{ display: 'flex', justifyContent: 'space-between' }}>
          <Typography variant="h6" component="div" style={{ fontFamily: 'Arial, sans-serif', fontWeight: 'bold', fontSize: '1.5rem', color: 'white' }}>
            Educational Website
          </Typography>
          <div>
            <Button color="inherit" >Home</Button>
            <Button color="inherit" onClick={handleAboutOpen} style={{ marginLeft: '10px', color: 'white', fontFamily: 'Arial, sans-serif', fontSize: '1rem' }}>About</Button>
            <Button color="inherit" onClick={handleContactOpen} style={{ marginLeft: '10px', color: 'white', fontFamily: 'Arial, sans-serif', fontSize: '1rem' }}>Contact</Button>
            
          </div>
        </Toolbar>
      </AppBar>
      <Container style={{ paddingTop: '20px' }}>
        <Dialog open={openAbout} onClose={handleAboutClose} maxWidth="md" fullWidth>
          <DialogTitle style={{ backgroundColor: '#1976d2', color: 'white' }}>About Our Educational Website</DialogTitle>
          <DialogContent>
            <DialogContentText style={{ fontFamily: 'Arial, sans-serif', fontSize: '1rem' }}>
              Our educational website is dedicated to providing students with comprehensive learning resources across various subjects and topics. We aim to empower students with the knowledge and skills necessary for academic success and personal growth.
              <br /><br />
              Whether you're studying mathematics, science, languages, or any other subject, our platform offers curated educational content, interactive tutorials, practice exercises, and more.
              <br /><br />
              At our educational website, we prioritize quality education and user-friendly learning experiences. Our team is committed to continuously improving our content and features to meet the evolving needs of students and educators alike.
              <br /><br />
              Thank you for choosing our educational website as your learning companion. We're here to support your educational journey every step of the way.
            </DialogContentText>
          </DialogContent>
        </Dialog>

        <Dialog open={openContact} onClose={handleContactClose} maxWidth="md" fullWidth>
          <DialogTitle style={{ backgroundColor: '#1976d2', color: 'white' }}>Contact Us</DialogTitle>
          <DialogContent>
            <DialogContentText style={{ fontFamily: 'Arial, sans-serif', fontSize: '1rem' }}>
              <strong>Email:</strong> contact@educationalwebsite.com
              <br />
              <strong>Phone:</strong> +1-123-456-7890
              <br />
              <strong>Address:</strong> 456 Learning Street, EduCity, USA
              <br /><br />
              For any inquiries, feedback, or support requests, please feel free to reach out to us using the contact information provided above. We're here to help you achieve your academic goals!
            </DialogContentText>
          </DialogContent>
        </Dialog>
      </Container>
    </>
  );
};

export default Navigation;

import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Registration() {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [regStatus, setRegStatus] = useState('');
    const navigate = useNavigate();

    function handleReg(e) {
        e.preventDefault();

        axios.post("http://localhost:5000/register", {
            username: username,
            email: email,
            password: password
        })
        
        .then((response) => {
            if (response.data.message) {
                setRegStatus(response.data.message);
            } else {
                setRegStatus("Registration Successful");
            }
        })
        .catch((error) => {
            console.error("Error:", error);
            setRegStatus("Registration failed. Please try again.");
        });
    }
   
    function goLogin() {
        navigate('/login'); 
    }

    return (
        <div>
            <h2>Registration Form</h2>
            <form onSubmit={handleReg}>
                <label>
                    Username:
                    <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                    />
                </label>
                <br />
                <label>
                    Email:
                    <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </label>
                <br />
                <label>
                    Password:
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </label>
                <br />
                <button type="submit">Register</button>
            </form>
            {regStatus && <p>{regStatus}</p>}
            <button onClick={goLogin}>Go to Login</button>
        </div>
    );
}

export default Registration;

import React from "react";
import { useNavigate } from "react-router-dom";

function Courses() {
    const navigate = useNavigate();

    function handleNav() {
        navigate("/home");
    }

    return (
        <div>
            <h1>Courses</h1>
            <button onClick={handleNav}>Go to Home</button>
        </div>
    );
}

export default Courses;

import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import './Login.css';

function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loginStatus, setLoginStatus] = useState('');
    const navigate = useNavigate();

    function handleLogin(e) {
        e.preventDefault();

        axios.post("http://localhost:5000/login", {
            email: email,
            password: password
        })
        .then((response) => {
            if (response.data.message) {
                setLoginStatus(response.data.message);
            } else {
                setLoginStatus("Login Successful");
                navigate('/home'); // Navigate to home page on successful login
            }
        })
        .catch((error) => {
            console.error("Error:", error);
            setLoginStatus("Login Failed. Please check your credentials and try again.");
        });
    }

    function goReg() {
        navigate('/registration'); // Navigate to registration page
    }

    return (
        <div className="login-container">
            <h2>Sign In</h2>
            <form onSubmit={handleLogin}>
                <label>
                    Email:
                    <input
                        type="text"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </label>
                <br />
                <label>
                    Password:
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </label>
                <br />
                <button type="submit">Login</button>
            </form>
            {loginStatus && <p>{loginStatus}</p>}
            <button onClick={goReg}>Go to Registration</button>
        </div>
    );
}

export default Login;

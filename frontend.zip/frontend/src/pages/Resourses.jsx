

import React from "react";
import { useNavigate } from "react-router-dom";

function Resources() {
    const navigate = useNavigate();

    function handleNav() {
        navigate("/home");
    }

    return (
        <>
            <h1>Resources</h1>
            <button onClick={handleNav}>Go to Home</button>
        </>
    );
}

export default Resources;

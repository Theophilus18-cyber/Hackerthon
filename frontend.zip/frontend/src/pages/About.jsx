function About(){
    return (
        <div>
            <h1>About Us</h1>
            <p>This is a website for educational purposes.</p>
        </div>
    )
}


export default About
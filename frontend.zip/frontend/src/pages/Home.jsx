import React, { useState } from "react";
import { Link } from "react-router-dom";
import Navigation from '../components/Navigation';


function Home() {
    const [showMenu, setShowMenu] = useState(false);

    const toggleMenu = () => {
        setShowMenu(!showMenu);
    };

    return (
        <div>
            <div className="header">
                <h1>Home page</h1>
                <button onClick={toggleMenu} className="menu-button">
                    <span className="menu-icon">&#9776;</span> {/* Hamburger icon */}
                </button>
            </div>
            {/* Conditional rendering of side menu based on showMenu state */}
            {showMenu && (
                <div className="side-menu">
                    <ul>
                        <li><Link to="/resources">Resources</Link></li>
                        <li><Link to="/community">Community</Link></li>
                        <li><Link to="/courses">Courses</Link></li>
                        {/* Add more links as needed */}
                    </ul>
                </div>
            )}
            <div className="main-content">
                {/* Your main content here */}
            </div>
        </div>
    );
}

export default Home;

const express = require("express")
const db = require('./config')
const cors = require('cors')

const app = express()

app.use(cors());


app.use(express.json());


app.post('/register', (req, res) => {
    const { username, email, password } = req.body;

    db.query("INSERT INTO Users (username, email, password) VALUES (?, ?, ?)", [username, email, password], 
        (err, result) => {
            if (err) {
                console.error("Error inserting data: ", err);
                res.status(500).json({ message: "Internal Server Error" });
            } else {
                res.status(200).json({ message: "Registration successful" });
            }
        }
    );
});


app.post("/login", (req, res) => {
    const { email, password } = req.body;  // Destructuring assignment to extract email and password

    db.query("SELECT * FROM users WHERE email = ? AND password = ?", [email, password], 
        (err, result) => {
            if (err) {
                res.status(500).json({ err });
            } else {
                if (result.length > 0) {
                    res.status(200).json(result);
                } else {
                    res.status(400).json({ message: "WRONG EMAIL OR PASSWORD!" });
                }
            }
        }
    );
});






app.listen(5000,()=>{
    console.log('Server is running on port 5000')
})